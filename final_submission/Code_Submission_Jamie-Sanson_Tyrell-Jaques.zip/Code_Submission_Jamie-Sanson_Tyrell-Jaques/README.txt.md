**This folder contains the code and outputs needed to reproduce the main results, figures, and tables in the final report.**



Code is split between the two "parts" of our project, available under hazard\_model/ and trading\_strategy/ respectively. Each folder has another README with additional information regarding the files within. Outputs are also included if you would prefer to skip running our code.



**Note: The raw SQLite database (polymarket.db) is not included because of file size. The main report results are reproducible directly from the exported modeling table timing\_model\_input\_bft\_cov2.csv and the included saved NetCDF outputs.**



**Folder contents**



**hazard\_model/  = Main Bayesian hazard-model analysis used in the report.**

**trading\_strategy/   = Spread-trading application / backtest used in the second-stage results section.**

**AI\_prompts\_log.txt   =  Verbatim AI prompt log referenced in the report.**



**Suggested grading workflow:**

* **Open hazard\_model/README\_hazard\_model.txt**
* **Inspect hazard\_model/timing\_model\_input\_bft\_cov2.csv**
* **Inspect hazard\_model/lambda\_model\_covrange\_nuts\_summary.csv**
* **Inspect hazard\_model/trace\_covrange.png**
* **Inspect hazard\_model/posterior\_predictive\_covrange.png**
* **Open trading\_strategy/README\_trading\_strategy.txt**
* **Inspect the backtest results figures and CSV outputs in trading\_strategy/backtest\_results/**

