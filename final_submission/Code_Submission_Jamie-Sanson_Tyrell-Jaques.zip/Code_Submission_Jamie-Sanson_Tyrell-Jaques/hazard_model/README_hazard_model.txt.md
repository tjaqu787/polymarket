**Hazard Model Reproducibility Guide** - This folder contains the final Bayesian hazard-model analysis used in the report.



**Main exported data table**



timing\_model\_input\_bft\_cov2.csv = Final exported modeling table used for the covariate-augmented model. This is the key input dataset named in our report.



**Main scripts**



analysis\_pipeline.sql - records of all SQL used in SQLite / Beekeeper Studio to identify timing markets, join price history, construct horizon snapshots, and build the exported analysis table. The report explicitly states that the SQL pipeline is recorded in this file.



run\_lambda\_model\_covrange\_collapsed.py - Final covariate-augmented Bayesian hazard model. Fits both ADVI and full NUTS.



plot\_diagnostics\_covrange.py - Generates the posterior density / trace diagnostic figure.



ppc\_covrange.py - Generates the posterior predictive check figure.



run\_lambda\_model\_covrange\_sensitivity.py - Prior-sensitivity version of the final model.


summarize\_covrange\_sens\_advi.py - Summarizes the sensitivity run.



**Saved outputs**



lambda\_model\_covrange\_advi.nc

lambda\_model\_covrange\_nuts.nc

lambda\_model\_covrange\_advi\_summary.csv

lambda\_model\_covrange\_nuts\_summary.csv

lambda\_model\_covrange\_sens\_advi.nc

lambda\_model\_covrange\_sens\_advi\_summary.csv



**Final report figures included here**



term\_structure\_fixed.png

trace\_covrange.png

prior\_predictive\_check.png

posterior\_predictive\_covrange.png



**What reproduces what**



Table 1 in the report comes from:

lambda\_model\_covrange\_advi\_summary.csv

lambda\_model\_covrange\_nuts\_summary.csv

Figure 1 = term\_structure\_fixed.png

Figure 2 = trace\_covrange.png

Figure 3 = prior\_predictive\_check.png

Figure 4 = posterior\_predictive\_covrange.png



**Fastest way to verify the methods used in our report**

Review our outputs by opening:



* timing\_model\_input\_bft\_cov2.csv
* lambda\_model\_covrange\_nuts\_summary.csv
* trace\_covrange.png
* posterior\_predictive\_covrange.png



**How to rerun the final model**

From inside hazard_model/ run:



python run\_lambda\_model\_covrange\_collapsed.py



* **Then generate figures:**



python plot\_diagnostics\_covrange.py

python ppc\_covrange.py



* **Sensitivity analysis:**



python run\_lambda\_model\_covrange\_sensitivity.py

python summarize\_covrange\_sens\_advi.py



**Dependencies**

See requirements.txt



Notes

Earlier exploratory / superseded scripts are not included in the main folder.

