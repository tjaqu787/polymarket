**Trading Application Reproducibility Guide** - This folder contains the second-stage trading application described in the final report.



Core idea - The report’s trading section studies a spread-dynamics strategy with Bayesian updating for position sizing. The backtesting engine is organized around a Strategy class, a DataLoader, a Portfolio object, and performance-metric calculation. The main backtesting engine imports those components directly, so they are included together here.



**Main files to inspect**



* run\_spread\_dynamics\_backtest.py
* Entry point for the spread-dynamics backtest.
* spread\_dynamics\_strategy.py
* Main strategy implementation referenced in the report.
* strategy.py
* Base strategy class.
* data\_loader.py
* Historical data loading utilities.
* engine.py
* Main backtesting engine.
* portfolio.py
* Portfolio and P\&L tracking.
* performance.py
* Performance metrics calculation.
* utils/kelly\_criterion.py
* Bayesian Kelly sizing helper.
* prior\_sensitivity\_analysis.py
* Prior sensitivity analysis for the trading strategy.
* plot\_signal\_to\_pnl.py
* Signal-to-PnL plotting utility.



**Outputs used in the report/presentation (within backtest\_results):**



* bayesian\_posteriors.csv
* prior\_sensitivity\_results.csv
* spread\_dynamics\_trades.csv
* signal\_to\_pnl.png
* The equity-curve / sensitivity figures used in our slide deck



**Optional files**



* visualization.py - Streamlit dashboard for exploring backtest results interactively. This is useful but not required to reproduce the static report outputs.
* BACKTEST\_README.md - Project-level documentation for the backtesting framework.



**Fastest way to verify the trading section**

**Open:**



backtest\_results/bayesian\_posteriors.csv

backtest\_results/prior\_sensitivity\_results.csv

the equity-curve figure used in the report

signal\_to\_pnl.png



**How to rerun**

In trading_strategy/ run:  python run\_spread\_dynamics\_backtest.py



**Dependencies**

See requirements.txt.





