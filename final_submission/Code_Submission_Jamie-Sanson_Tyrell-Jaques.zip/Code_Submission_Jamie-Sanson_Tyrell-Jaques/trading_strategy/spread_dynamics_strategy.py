"""
SpreadDynamicsStrategy - Trades the anticipated change in implied rate spreads.

This strategy operates on the velocity and direction of spread change between
adjacent contracts in term structures, conditioned on volume regime.

Unlike strategies that react to current mispricings, this one positions before
the spread moves, by detecting regime conditions that historically precede
spread compression or widening.
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
from collections import defaultdict

from backtest.strategy import Strategy, Signal, SignalType
from utils.implied_rates import calculate_implied_rate, calculate_time_to_expiration


class SpreadDynamicsStrategy(Strategy):
    """
    Trades the anticipated change in implied rate spreads, not the level.

    Enters positions before expected spread compression or widening,
    using volume regime, spread velocity, and rate momentum as signals.

    Two trade types:
        - COMPRESSION trade: short the wide leg, long the tight leg
          (spread expected to narrow after news/volume spike)
        - WIDENING trade: long the wide leg, short the tight leg
          (spread expected to widen during inactivity)
    """

    def __init__(self, config: Optional[Dict] = None):
        super().__init__(config)

        # Strategy parameters
        self.lookback_days = self.config.get('lookback_days', 7)
        self.vol_lookback_days = self.config.get('vol_lookback_days', 3)
        self.vol_spike_threshold = self.config.get('vol_spike_threshold', 2.0)
        self.vol_drought_threshold = self.config.get('vol_drought_threshold', -0.5)
        self.min_spread_change = self.config.get('min_spread_change', 0.05)
        self.min_spread_level = self.config.get('min_spread_level', 0.02)
        self.min_tte_days = self.config.get('min_tte_days', 14)
        self.min_volume = self.config.get('min_volume', 300)
        self.refit_days = self.config.get('refit_days', 1)
        self.kelly_fraction = self.config.get('kelly_fraction', 0.25)
        self.max_position = self.config.get('max_position', 0.10)
        self.max_event_exposure = self.config.get('max_event_exposure', 0.20)
        self.min_pair_correlation = self.config.get('min_pair_correlation', 0.60)

        # Bayesian Kelly parameters
        self.prior_edge_mean = self.config.get('prior_edge_mean', 0.0)  # Prior belief about edge
        self.prior_edge_std = self.config.get('prior_edge_std', 0.05)   # Prior uncertainty
        self.obs_std = self.config.get('obs_std', 0.02)                 # Observation noise
        self.use_bayesian_kelly = self.config.get('use_bayesian_kelly', True)

        # Regime-specific Kelly adjustments
        self.compression_regime_factor = self.config.get('compression_regime_factor', 1.0)  # Scaling for compression trades
        self.widening_regime_factor = self.config.get('widening_regime_factor', 0.85)     # Scaling for widening trades (more uncertain)

        # State tracking
        self.spread_positions = {}  # (event_id, near_market_id, far_market_id) -> trade info
        self.spread_history = {}  # pair_id -> DataFrame with spread time series
        self.volume_history = {}  # event_id -> DataFrame with volume time series
        self.last_refit_date = None
        self.spread_velocity_history = {}  # pair_id -> list of velocities for variance estimation

        # Bayesian posterior tracking: (pair_id, trade_type) -> {'mu': mean, 'sigma': std, 'n_obs': count}
        # Track separate posteriors for compression vs widening regimes
        self.edge_posterior = defaultdict(lambda: {
            'mu': self.prior_edge_mean,
            'sigma': self.prior_edge_std,
            'n_obs': 0
        })

        # Signal-to-noise tracking
        self.signal_history = []  # List of {date, pair_id, trade_type, spread_velocity, vol_zscore, traded: bool}
        self.trade_count_by_date = defaultdict(int)  # date -> count
        self.trade_count_by_regime = defaultdict(int)  # trade_type -> count

    @property
    def name(self) -> str:
        return (f"SpreadDynamics_LB{self.lookback_days}_"
                f"Vol{self.vol_lookback_days}_"
                f"MinSpd{int(self.min_spread_change*100)}")

    def calculate_volume_zscore(self, event_id: str, current_date: pd.Timestamp,
                                data: pd.DataFrame) -> float:
        """
        Calculate volume z-score for regime classification.

        Args:
            event_id: Event group ID (not used, data is pre-filtered)
            current_date: Current date
            data: Historical data (pre-filtered for this event)

        Returns:
            Volume z-score (standardized volume change)
        """
        # Data is already filtered for this event, no need to filter again
        if data.empty:
            return 0.0

        # OPTIMIZATION: Vectorized volume aggregation
        daily_volume = data.groupby('date')['volume_num'].sum()

        if len(daily_volume) < self.vol_lookback_days + 1:
            return 0.0

        # Get recent volume history (vectorized filtering)
        lookback_end = current_date - pd.Timedelta(days=1)
        lookback_start = lookback_end - pd.Timedelta(days=self.vol_lookback_days)

        recent_volumes = daily_volume[(daily_volume.index >= lookback_start) &
                                      (daily_volume.index <= lookback_end)]

        if len(recent_volumes) < 2:
            return 0.0

        # Vectorized z-score calculation
        current_volume = daily_volume.get(current_date, 0)
        mean_volume = recent_volumes.mean()
        std_volume = recent_volumes.std()

        if std_volume == 0 or pd.isna(std_volume):
            return 0.0

        z_score = (current_volume - mean_volume) / std_volume
        return z_score

    def build_spread_pairs(self, event_id: str, current_date: pd.Timestamp,
                          data: pd.DataFrame) -> List[Tuple[Dict, Dict]]:
        """
        Build adjacent pairs of contracts for spread trading.

        Args:
            event_id: Event group ID (not used, data is pre-filtered)
            current_date: Current date
            data: Market data (pre-filtered for this event)

        Returns:
            List of (near_contract, far_contract) tuples
        """
        pairs = []

        # Data is already filtered for this event, just filter by date and outcome
        event_data = data[
            (data['date'] == current_date) &
            (data['outcome'] == 'No')
        ]

        if event_data.empty:
            return pairs

        # Calculate days to expiration
        event_data['days_to_expiry'] = (
            event_data['resolution_date'] - current_date
        ).dt.days

        # Filter by minimum TTE and volume
        event_data = event_data[
            (event_data['days_to_expiry'] >= self.min_tte_days) &
            (event_data['volume_num'] >= self.min_volume)
        ]

        if len(event_data) < 2:
            return pairs

        # Sort by time to expiration
        event_data = event_data.sort_values('days_to_expiry')

        # Create adjacent pairs
        for i in range(len(event_data) - 1):
            near = event_data.iloc[i]
            far = event_data.iloc[i + 1]

            near_dict = {
                'market_id': near['market_id'],
                'token_id': near['token_id'],
                'price': near['price'],
                'tte_years': near['time_to_expiration'],
                'tte_days': near['days_to_expiry'],
                'volume': near['volume_num']
            }

            far_dict = {
                'market_id': far['market_id'],
                'token_id': far['token_id'],
                'price': far['price'],
                'tte_years': far['time_to_expiration'],
                'tte_days': far['days_to_expiry'],
                'volume': far['volume_num']
            }

            pairs.append((near_dict, far_dict))

        # Also add the full-span pair if we have more than 2 contracts
        if len(event_data) > 2:
            near = event_data.iloc[0]
            far = event_data.iloc[-1]

            near_dict = {
                'market_id': near['market_id'],
                'token_id': near['token_id'],
                'price': near['price'],
                'tte_years': near['time_to_expiration'],
                'tte_days': near['days_to_expiry'],
                'volume': near['volume_num']
            }

            far_dict = {
                'market_id': far['market_id'],
                'token_id': far['token_id'],
                'price': far['price'],
                'tte_years': far['time_to_expiration'],
                'tte_days': far['days_to_expiry'],
                'volume': far['volume_num']
            }

            pairs.append((near_dict, far_dict))

        return pairs

    def calculate_spread(self, near: Dict, far: Dict) -> Optional[float]:
        """
        Calculate implied rate spread between two contracts.

        Args:
            near: Near contract data
            far: Far contract data

        Returns:
            Spread (λ_far - λ_near) or None if calculation fails
        """
        # Calculate implied rates
        lambda_near = calculate_implied_rate(near['price'], near['tte_years'])
        lambda_far = calculate_implied_rate(far['price'], far['tte_years'])

        if pd.isna(lambda_near) or pd.isna(lambda_far):
            return None

        spread = lambda_far - lambda_near
        return spread

    def get_spread_history(self, pair_id: str, current_date: pd.Timestamp,
                          data: pd.DataFrame, near_market_id: str,
                          far_market_id: str) -> Optional[pd.DataFrame]:
        """
        Get or compute spread history for a pair.

        Args:
            pair_id: Unique pair identifier
            current_date: Current date
            data: Historical data (pre-filtered for this event)
            near_market_id: Near contract market ID
            far_market_id: Far contract market ID

        Returns:
            DataFrame with dates and spread values, or None if insufficient data
        """
        # OPTIMIZATION: Check cache first
        if pair_id in self.spread_history:
            cached = self.spread_history[pair_id]
            # If cache has current_date, return it
            if current_date in cached['date'].values:
                return cached[cached['date'] <= current_date]

        # Get historical data for both markets (data is already event-filtered)
        near_data = data[
            (data['market_id'] == near_market_id) &
            (data['outcome'] == 'No') &
            (data['date'] <= current_date)
        ].sort_values('date')

        far_data = data[
            (data['market_id'] == far_market_id) &
            (data['outcome'] == 'No') &
            (data['date'] <= current_date)
        ].sort_values('date')

        if near_data.empty or far_data.empty:
            return None

        # Merge on date
        merged = pd.merge(
            near_data[['date', 'price', 'time_to_expiration']],
            far_data[['date', 'price', 'time_to_expiration']],
            on='date',
            suffixes=('_near', '_far')
        )

        if len(merged) < self.lookback_days:
            return None

        # OPTIMIZATION: Vectorized spread calculation instead of iterrows
        # Convert to numpy arrays for faster computation
        price_near = merged['price_near'].values
        price_far = merged['price_far'].values
        tte_near = merged['time_to_expiration_near'].values
        tte_far = merged['time_to_expiration_far'].values

        # Clip prices to avoid log(0) or log(negative)
        yes_price_near = np.clip(1 - price_near, 1e-6, 1-1e-6)
        yes_price_far = np.clip(1 - price_far, 1e-6, 1-1e-6)

        # Vectorized implied rate calculation: λ = -ln(1-p) / t
        lambda_near = -np.log(yes_price_near) / tte_near
        lambda_far = -np.log(yes_price_far) / tte_far

        # Calculate spreads
        spreads = lambda_far - lambda_near
        merged['spread'] = spreads
        merged = merged.dropna(subset=['spread'])

        result = merged[['date', 'spread']]

        # OPTIMIZATION: Cache the result (keep last 30 days to limit memory)
        if len(result) > 0:
            self.spread_history[pair_id] = result.tail(30)

        return result

    def generate_spread_signals(self, event_id: str, current_date: pd.Timestamp,
                               data: pd.DataFrame) -> List[Signal]:
        """
        Generate signals for spread trades.

        Args:
            event_id: Event group ID
            current_date: Current date
            data: Historical data

        Returns:
            List of trading signals
        """
        signals = []

        # Calculate volume regime
        vol_zscore = self.calculate_volume_zscore(event_id, current_date, data)

        # Classify regime
        if vol_zscore > self.vol_spike_threshold:
            volume_regime = 'news'  # Expect compression
        elif vol_zscore < self.vol_drought_threshold:
            volume_regime = 'inactive'  # Expect widening
        else:
            volume_regime = 'neutral'  # No clear signal

        # Build spread pairs
        pairs = self.build_spread_pairs(event_id, current_date, data)

        for near, far in pairs:
            pair_id = f"{event_id}_{near['market_id']}_{far['market_id']}"
            position_key = (event_id, near['market_id'], far['market_id'])

            # Calculate current spread
            current_spread = self.calculate_spread(near, far)
            if current_spread is None or abs(current_spread) < self.min_spread_level:
                continue

            # Get spread history
            spread_hist = self.get_spread_history(
                pair_id, current_date, data,
                near['market_id'], far['market_id']
            )

            if spread_hist is None or len(spread_hist) < self.lookback_days:
                continue

            # Calculate spread velocity
            spread_lookback = spread_hist.iloc[-self.lookback_days]['spread']
            spread_change = current_spread - spread_lookback
            spread_velocity = spread_change / self.lookback_days

            # Check if we already have a position
            existing_position = self.spread_positions.get(position_key)

            # === EXIT SIGNALS ===
            if existing_position:
                entry_spread = existing_position['entry_spread']
                trade_type = existing_position['trade_type']

                # Check exit conditions
                spread_moved = current_spread - entry_spread

                # Take profit: spread moved in expected direction by ≥ 50% of min_spread_change
                if trade_type == 'compression' and spread_moved < -0.5 * self.min_spread_change:
                    # Spread compressed as expected - close both legs
                    signals.extend(self._generate_close_signals(
                        position_key, near, far, current_spread,
                        f"Take profit: Spread compressed {spread_moved:.4f}"
                    ))
                    continue

                elif trade_type == 'widening' and spread_moved > 0.5 * self.min_spread_change:
                    # Spread widened as expected - close both legs
                    signals.extend(self._generate_close_signals(
                        position_key, near, far, current_spread,
                        f"Take profit: Spread widened {spread_moved:.4f}"
                    ))
                    continue

                # Stop loss: spread moved against position
                if trade_type == 'compression' and spread_moved > self.min_spread_change:
                    signals.extend(self._generate_close_signals(
                        position_key, near, far, current_spread,
                        f"Stop loss: Spread widened {spread_moved:.4f}"
                    ))
                    continue

                elif trade_type == 'widening' and spread_moved < -self.min_spread_change:
                    signals.extend(self._generate_close_signals(
                        position_key, near, far, current_spread,
                        f"Stop loss: Spread compressed {spread_moved:.4f}"
                    ))
                    continue

                # Volume regime flip
                entry_regime = 'news' if existing_position['entry_vol_zscore'] > self.vol_spike_threshold else 'inactive'
                if entry_regime != volume_regime and volume_regime != 'neutral':
                    signals.extend(self._generate_close_signals(
                        position_key, near, far, current_spread,
                        f"Regime flip: {entry_regime} -> {volume_regime}"
                    ))
                    continue

                # TTE check
                if near['tte_days'] < self.min_tte_days or far['tte_days'] < self.min_tte_days:
                    signals.extend(self._generate_close_signals(
                        position_key, near, far, current_spread,
                        "TTE below minimum"
                    ))
                    continue

            # === ENTRY SIGNALS ===
            else:
                # Skip if change is too small
                if abs(spread_change) < self.min_spread_change:
                    continue

                # Compression trade: spread widening + volume spike
                if (spread_velocity > 0 and volume_regime == 'news'):
                    # Position size based on edge
                    position_size = self._calculate_position_size(
                        pair_id, abs(spread_velocity), 'compression'
                    )

                    # Track signal for signal-to-noise metrics
                    self.signal_history.append({
                        'date': current_date,
                        'pair_id': pair_id,
                        'trade_type': 'compression',
                        'spread_velocity': spread_velocity,
                        'vol_zscore': vol_zscore,
                        'traded': position_size > 0
                    })

                    if position_size > 0:
                        # Track trade count by regime
                        self.trade_count_by_regime['compression'] += 1
                        self.trade_count_by_date[current_date] += 1
                        # SHORT far leg, LONG near leg
                        signals.append(Signal(
                            market_id=far['market_id'],
                            token_id=far['token_id'],
                            outcome='No',
                            signal_type=SignalType.SELL,
                            size=position_size,
                            price=far['price'],
                            reason=f"Spread compression: vol_spike (z={vol_zscore:.2f}) + spread_widening (Δ={spread_change:.4f})",
                            metadata={
                                'trade_type': 'compression',
                                'pair_id': pair_id,
                                'spread_level': current_spread,
                                'spread_velocity': spread_velocity,
                                'vol_zscore': vol_zscore,
                                'regime_factor': self.compression_regime_factor,
                                'leg': 'far',
                                'near_market_id': near['market_id'],
                                'far_market_id': far['market_id'],
                                'volume': far['volume']
                            }
                        ))

                        signals.append(Signal(
                            market_id=near['market_id'],
                            token_id=near['token_id'],
                            outcome='No',
                            signal_type=SignalType.BUY,
                            size=position_size,
                            price=near['price'],
                            reason=f"Spread compression: vol_spike (z={vol_zscore:.2f}) + spread_widening (Δ={spread_change:.4f})",
                            metadata={
                                'trade_type': 'compression',
                                'pair_id': pair_id,
                                'spread_level': current_spread,
                                'spread_velocity': spread_velocity,
                                'vol_zscore': vol_zscore,
                                'regime_factor': self.compression_regime_factor,
                                'leg': 'near',
                                'near_market_id': near['market_id'],
                                'far_market_id': far['market_id'],
                                'volume': near['volume']
                            }
                        ))

                        # Track position
                        self.spread_positions[position_key] = {
                            'trade_type': 'compression',
                            'entry_spread': current_spread,
                            'entry_spread_velocity': spread_velocity,
                            'entry_date': current_date,
                            'entry_vol_zscore': vol_zscore,
                            'near_leg_size': position_size,
                            'far_leg_size': position_size
                        }

                # Widening trade: spread compressing + volume drought OR spread widening + inactive
                elif ((spread_velocity < 0 and volume_regime == 'inactive') or
                      (spread_velocity > 0 and volume_regime == 'inactive')):

                    position_size = self._calculate_position_size(
                        pair_id, abs(spread_velocity), 'widening'
                    )

                    # Track signal for signal-to-noise metrics
                    self.signal_history.append({
                        'date': current_date,
                        'pair_id': pair_id,
                        'trade_type': 'widening',
                        'spread_velocity': spread_velocity,
                        'vol_zscore': vol_zscore,
                        'traded': position_size > 0
                    })

                    if position_size > 0:
                        # Track trade count by regime
                        self.trade_count_by_regime['widening'] += 1
                        self.trade_count_by_date[current_date] += 1
                        # LONG far leg, SHORT near leg
                        signals.append(Signal(
                            market_id=far['market_id'],
                            token_id=far['token_id'],
                            outcome='No',
                            signal_type=SignalType.BUY,
                            size=position_size,
                            price=far['price'],
                            reason=f"Spread widening: vol_drought (z={vol_zscore:.2f}) + spread_velocity={spread_velocity:.4f}",
                            metadata={
                                'trade_type': 'widening',
                                'pair_id': pair_id,
                                'spread_level': current_spread,
                                'spread_velocity': spread_velocity,
                                'vol_zscore': vol_zscore,
                                'regime_factor': self.widening_regime_factor,
                                'leg': 'far',
                                'near_market_id': near['market_id'],
                                'far_market_id': far['market_id'],
                                'volume': far['volume']
                            }
                        ))

                        signals.append(Signal(
                            market_id=near['market_id'],
                            token_id=near['token_id'],
                            outcome='No',
                            signal_type=SignalType.SELL,
                            size=position_size,
                            price=near['price'],
                            reason=f"Spread widening: vol_drought (z={vol_zscore:.2f}) + spread_velocity={spread_velocity:.4f}",
                            metadata={
                                'trade_type': 'widening',
                                'pair_id': pair_id,
                                'spread_level': current_spread,
                                'spread_velocity': spread_velocity,
                                'vol_zscore': vol_zscore,
                                'regime_factor': self.widening_regime_factor,
                                'leg': 'near',
                                'near_market_id': near['market_id'],
                                'far_market_id': far['market_id'],
                                'volume': near['volume']
                            }
                        ))

                        # Track position
                        self.spread_positions[position_key] = {
                            'trade_type': 'widening',
                            'entry_spread': current_spread,
                            'entry_spread_velocity': spread_velocity,
                            'entry_date': current_date,
                            'entry_vol_zscore': vol_zscore,
                            'near_leg_size': position_size,
                            'far_leg_size': position_size
                        }

        return signals

    def update_edge_posterior(self, pair_id: str, observed_return: float, trade_type: str):
        """
        Bayesian update of edge posterior after observing a trade outcome.

        Uses Normal-Normal conjugate prior for analytical posterior.
        Tracks separate posteriors for compression vs widening trades.

        Args:
            pair_id: Pair identifier
            observed_return: Realized return from the trade (spread change)
            trade_type: Trade regime ('compression' or 'widening')
        """
        posterior_key = (pair_id, trade_type)
        posterior = self.edge_posterior[posterior_key]

        # Prior: edge ~ N(μ₀, σ₀²)
        mu_prior = posterior['mu']
        sigma_prior = posterior['sigma']

        # Likelihood: return ~ N(edge, σ_obs²)
        sigma_obs = self.obs_std

        # Posterior (Normal-Normal conjugate):
        # σ_n² = 1 / (1/σ₀² + 1/σ_obs²)
        precision_prior = 1 / (sigma_prior ** 2)
        precision_obs = 1 / (sigma_obs ** 2)
        precision_posterior = precision_prior + precision_obs
        sigma_posterior = np.sqrt(1 / precision_posterior)

        # μ_n = σ_n² * (μ₀/σ₀² + r/σ_obs²)
        mu_posterior = (sigma_posterior ** 2) * (
            mu_prior * precision_prior + observed_return * precision_obs
        )

        # Update stored posterior
        self.edge_posterior[posterior_key] = {
            'mu': mu_posterior,
            'sigma': sigma_posterior,
            'n_obs': posterior['n_obs'] + 1
        }

    def _calculate_position_size(self, pair_id: str, edge: float, trade_type: str) -> float:
        """
        Calculate position size using Bayesian Kelly criterion with regime factor.

        Combines observed signal (edge) with learned posterior beliefs.
        Uncertainty penalty reduces bets when we're unsure about pair's true edge.
        Regime factor adjusts sizing based on trade type (compression vs widening).

        Args:
            pair_id: Pair identifier
            edge: Observed spread velocity (current signal strength)
            trade_type: Trade regime ('compression' or 'widening')

        Returns:
            Position size as fraction of capital
        """
        if self.use_bayesian_kelly:
            # Use regime-specific posterior: (pair_id, trade_type)
            posterior_key = (pair_id, trade_type)
            posterior = self.edge_posterior[posterior_key]
            mu_posterior = posterior['mu']
            sigma_posterior = posterior['sigma']
            n_obs = posterior['n_obs']

            # Combine observed signal with posterior belief
            # For new pairs (n_obs = 0), use observed edge
            # For experienced pairs, blend observation with posterior
            if n_obs == 0:
                # No history: use observed edge but apply uncertainty penalty
                effective_edge = edge
            else:
                # Blend observed signal with learned posterior
                # Weight by inverse variance (precision)
                precision_obs = 1 / (self.obs_std ** 2)
                precision_posterior = 1 / (sigma_posterior ** 2)
                total_precision = precision_obs + precision_posterior

                # Precision-weighted average
                effective_edge = (edge * precision_obs + mu_posterior * precision_posterior) / total_precision

            # Bayesian Kelly with uncertainty penalty
            # High posterior variance → reduce position size
            sigma_obs = self.obs_std
            total_variance = sigma_obs ** 2 + sigma_posterior ** 2

            if total_variance == 0:
                return self.max_position

            # Standard Kelly formula with effective edge and uncertainty-adjusted variance
            position_size = self.kelly_fraction * (effective_edge / total_variance)

            # Additional uncertainty penalty for new pairs
            if n_obs < 5:
                uncertainty_discount = 1.0 - (5 - n_obs) * 0.1  # 0.5x for first trade, 1.0x after 5 trades
                position_size *= max(uncertainty_discount, 0.5)

            # Apply regime-specific factor
            regime_factor = self.compression_regime_factor if trade_type == 'compression' else self.widening_regime_factor
            position_size *= regime_factor

        else:
            # Original non-Bayesian Kelly
            if pair_id in self.spread_velocity_history and len(self.spread_velocity_history[pair_id]) > 5:
                velocities = self.spread_velocity_history[pair_id]
                edge_variance = np.var(velocities)
            else:
                edge_variance = (edge ** 2) / 4

            if edge_variance == 0:
                return self.max_position

            position_size = self.kelly_fraction * (edge / np.sqrt(edge_variance))

            # Apply regime-specific factor for non-Bayesian as well
            regime_factor = self.compression_regime_factor if trade_type == 'compression' else self.widening_regime_factor
            position_size *= regime_factor

        # Apply bounds
        position_size = min(position_size, self.max_position)
        position_size = max(position_size, 0.0)

        return position_size

    def _generate_close_signals(self, position_key: Tuple, near: Dict, far: Dict,
                                current_spread: float, reason: str) -> List[Signal]:
        """
        Generate signals to close both legs of a spread trade.

        Updates Bayesian posterior based on realized trade outcome.

        Args:
            position_key: Position identifier
            near: Near contract data
            far: Far contract data
            current_spread: Current spread level
            reason: Exit reason

        Returns:
            List of close signals for both legs
        """
        signals = []
        position = self.spread_positions[position_key]

        # BAYESIAN UPDATE: Calculate realized return for this trade
        event_id, near_market_id, far_market_id = position_key
        pair_id = f"{event_id}_{near_market_id}_{far_market_id}"

        entry_spread = position['entry_spread']
        spread_change = current_spread - entry_spread

        # Realized return depends on trade type:
        # - Compression: profit when spread narrows (spread_change < 0)
        # - Widening: profit when spread widens (spread_change > 0)
        if position['trade_type'] == 'compression':
            realized_return = -spread_change  # Negative change = profit
        else:  # widening
            realized_return = spread_change   # Positive change = profit

        # Update Bayesian posterior with this observation (regime-specific)
        self.update_edge_posterior(pair_id, realized_return, position['trade_type'])

        # Close near leg (reverse the original trade)
        if position['trade_type'] == 'compression':
            # Original: LONG near -> Close with SELL
            signals.append(Signal(
                market_id=near['market_id'],
                token_id=near['token_id'],
                outcome='No',
                signal_type=SignalType.SELL,
                size=position['near_leg_size'],
                price=near['price'],
                reason=f"Close spread {position['trade_type']}: {reason}",
                metadata={
                    'exit_spread': current_spread,
                    'entry_spread': position['entry_spread'],
                    'leg': 'near'
                }
            ))
        else:  # widening
            # Original: SHORT near -> Close with BUY
            signals.append(Signal(
                market_id=near['market_id'],
                token_id=near['token_id'],
                outcome='No',
                signal_type=SignalType.BUY,
                size=position['near_leg_size'],
                price=near['price'],
                reason=f"Close spread {position['trade_type']}: {reason}",
                metadata={
                    'exit_spread': current_spread,
                    'entry_spread': position['entry_spread'],
                    'leg': 'near'
                }
            ))

        # Close far leg (reverse the original trade)
        if position['trade_type'] == 'compression':
            # Original: SHORT far -> Close with BUY
            signals.append(Signal(
                market_id=far['market_id'],
                token_id=far['token_id'],
                outcome='No',
                signal_type=SignalType.BUY,
                size=position['far_leg_size'],
                price=far['price'],
                reason=f"Close spread {position['trade_type']}: {reason}",
                metadata={
                    'exit_spread': current_spread,
                    'entry_spread': position['entry_spread'],
                    'leg': 'far'
                }
            ))
        else:  # widening
            # Original: LONG far -> Close with SELL
            signals.append(Signal(
                market_id=far['market_id'],
                token_id=far['token_id'],
                outcome='No',
                signal_type=SignalType.SELL,
                size=position['far_leg_size'],
                price=far['price'],
                reason=f"Close spread {position['trade_type']}: {reason}",
                metadata={
                    'exit_spread': current_spread,
                    'entry_spread': position['entry_spread'],
                    'leg': 'far'
                }
            ))

        # Remove position from tracking
        del self.spread_positions[position_key]

        return signals

    def on_data(self, current_date: pd.Timestamp, data: pd.DataFrame) -> List[Signal]:
        """
        Process new data and generate trading signals.

        Args:
            current_date: Current timestamp in backtest
            data: Market data up to current_date

        Returns:
            List of trading signals
        """
        signals = []

        # Get unique event groups
        if 'group_col' not in data.columns:
            return signals

        # OPTIMIZATION: Filter to recent window only (lookback + vol lookback)
        # We only need last N days for spread velocity and volume regime
        max_lookback = max(self.lookback_days, self.vol_lookback_days) + 2  # +2 buffer
        cutoff_date = current_date - pd.Timedelta(days=max_lookback)
        recent_data = data[data['date'] >= cutoff_date]

        # OPTIMIZATION: Pre-group by event to avoid repeated filtering
        # This reduces 6,572 full scans to 1 groupby operation
        grouped = recent_data.groupby('group_col')

        # Process each event group
        for event_id, event_data in grouped:
            if pd.isna(event_id):
                continue

            # Generate signals for this event (pass pre-filtered data)
            event_signals = self.generate_spread_signals(event_id, current_date, event_data)
            signals.extend(event_signals)

        return signals

    def on_market_close(self, market_id: str, outcome: str, final_price: float):
        """
        Called when one leg of a spread pair resolves.
        Immediately close the other leg.

        Args:
            market_id: Market that closed
            outcome: Winning outcome
            final_price: Final settlement price
        """
        super().on_market_close(market_id, outcome, final_price)

        # Find any spread positions containing this market
        positions_to_remove = []

        for position_key in list(self.spread_positions.keys()):
            event_id, near_market_id, far_market_id = position_key

            if market_id in [near_market_id, far_market_id]:
                # One leg has resolved - remove from tracking
                # The engine will handle the settlement
                positions_to_remove.append(position_key)

        for position_key in positions_to_remove:
            del self.spread_positions[position_key]

    def reset(self):
        """Reset strategy state."""
        super().reset()
        self.spread_positions = {}
        self.spread_history = {}
        self.volume_history = {}
        self.last_refit_date = None
        self.spread_velocity_history = {}
        # Reset Bayesian posteriors to prior
        self.edge_posterior = defaultdict(lambda: {
            'mu': self.prior_edge_mean,
            'sigma': self.prior_edge_std,
            'n_obs': 0
        })
        # Reset signal-to-noise tracking
        self.signal_history = []
        self.trade_count_by_date = defaultdict(int)
        self.trade_count_by_regime = defaultdict(int)

    def get_posterior_stats(self) -> pd.DataFrame:
        """
        Get summary statistics of Bayesian posteriors for all pairs.

        Returns:
            DataFrame with posterior mean, std, and number of observations per pair/regime
        """
        stats = []
        for posterior_key, posterior in self.edge_posterior.items():
            # Handle both old format (str) and new format (tuple)
            if isinstance(posterior_key, tuple):
                pair_id, trade_type = posterior_key
            else:
                pair_id = posterior_key
                trade_type = 'unknown'

            stats.append({
                'pair_id': pair_id,
                'trade_type': trade_type,
                'posterior_mean': posterior['mu'],
                'posterior_std': posterior['sigma'],
                'n_observations': posterior['n_obs'],
                'prior_std': self.prior_edge_std,
                'uncertainty_reduction': 1 - (posterior['sigma'] / self.prior_edge_std)
            })

        return pd.DataFrame(stats) if stats else pd.DataFrame()

    def get_signal_to_noise_metrics(self) -> Dict:
        """
        Calculate signal-to-noise metrics to identify overtrading.

        Returns:
            Dict with various signal quality and trading frequency metrics
        """
        if not self.signal_history:
            return {}

        df = pd.DataFrame(self.signal_history)

        # 1. Trade Frequency Metrics
        total_signals = len(df)
        total_trades = df['traded'].sum()
        signal_to_trade_ratio = total_trades / total_signals if total_signals > 0 else 0

        unique_dates = df['date'].nunique()
        trades_per_day = total_trades / unique_dates if unique_dates > 0 else 0

        # 2. Signal Quality Metrics
        # Calculate signal-to-noise ratio: mean absolute signal / std of signal
        signal_strength = df['spread_velocity'].abs().mean()
        signal_noise = df['spread_velocity'].std()
        velocity_snr = signal_strength / signal_noise if signal_noise > 0 else 0

        vol_zscore_strength = df['vol_zscore'].abs().mean()
        vol_zscore_noise = df['vol_zscore'].std()
        vol_snr = vol_zscore_strength / vol_zscore_noise if vol_zscore_noise > 0 else 0

        # 3. Regime-specific metrics
        regime_stats = {}
        for trade_type in df['trade_type'].unique():
            regime_df = df[df['trade_type'] == trade_type]
            traded_df = regime_df[regime_df['traded']]

            regime_stats[trade_type] = {
                'total_signals': len(regime_df),
                'total_trades': len(traded_df),
                'signal_to_trade_ratio': len(traded_df) / len(regime_df) if len(regime_df) > 0 else 0,
                'avg_velocity': regime_df['spread_velocity'].abs().mean(),
                'avg_vol_zscore': regime_df['vol_zscore'].abs().mean()
            }

        # 4. Edge Confidence Metrics (from Bayesian posteriors)
        edge_confidence_metrics = []
        for posterior_key, posterior in self.edge_posterior.items():
            if posterior['n_obs'] > 0:
                # Edge confidence: like a Sharpe ratio for edge (mean / std)
                edge_confidence = abs(posterior['mu']) / posterior['sigma'] if posterior['sigma'] > 0 else 0
                edge_confidence_metrics.append(edge_confidence)

        avg_edge_confidence = np.mean(edge_confidence_metrics) if edge_confidence_metrics else 0
        max_edge_confidence = np.max(edge_confidence_metrics) if edge_confidence_metrics else 0

        # 5. Trade Clustering (how concentrated are trades in time)
        trades_by_date = df[df['traded']].groupby('date').size()
        avg_trades_per_active_day = trades_by_date.mean() if len(trades_by_date) > 0 else 0
        max_trades_per_day = trades_by_date.max() if len(trades_by_date) > 0 else 0
        active_days = len(trades_by_date)

        return {
            'total_signals': total_signals,
            'total_trades': total_trades,
            'signal_to_trade_ratio': signal_to_trade_ratio,
            'trades_per_day': trades_per_day,
            'velocity_snr': velocity_snr,
            'vol_zscore_snr': vol_snr,
            'regime_stats': regime_stats,
            'avg_edge_confidence': avg_edge_confidence,
            'max_edge_confidence': max_edge_confidence,
            'avg_trades_per_active_day': avg_trades_per_active_day,
            'max_trades_per_day': max_trades_per_day,
            'active_trading_days': active_days,
            'unique_pairs_traded': df[df['traded']]['pair_id'].nunique()
        }
